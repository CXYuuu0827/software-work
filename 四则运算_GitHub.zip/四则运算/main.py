# -*- coding: utf-8 -*-
"""四则运算出题器 —— 桌面界面（pywebview + HTML/CSS/JS，标准 WebView2 承载）。"""

import os
import sys

import webview

from arithmetic_generator import generate_problems

WINDOW_TITLE = '四则运算出题器'
WINDOW_SIZE = (780, 760)
MIN_SIZE = (520, 600)


def _asset_path(name):
    """返回资源文件路径，兼容 PyInstaller 打包（frozen）与直接运行。"""
    base = getattr(sys, '_MEIPASS', None) or os.path.dirname(os.path.abspath(__file__))
    return os.path.join(base, name)


class Api:
    """暴露给前端 JS 的接口：window.pywebview.api.<方法名>。"""

    def generate(self, n, num_operands, ops, lo, hi, nonneg):
        """生成 n 道题。返回 [(中缀表达式, 答案), ...]，失败项为 (None, None)。"""
        return generate_problems(n, num_operands, ops, lo, hi, nonneg)

    def export(self, text):
        """弹出系统保存对话框，把 text 写入用户选择的文件。"""
        result = webview.windows[0].create_file_dialog(
            webview.SAVE_DIALOG,
            save_filename='四则运算题目.txt',
            file_types=('文本文件 (*.txt)', '所有文件 (*.*)'),
        )
        if not result:
            return {'ok': False, 'cancelled': True}
        path = result[0]
        with open(path, 'w', encoding='utf-8') as f:
            f.write(text)
        return {'ok': True, 'path': path}


def main():
    webview.create_window(
        WINDOW_TITLE,
        _asset_path(os.path.join('web', 'index.html')),
        js_api=Api(),
        width=WINDOW_SIZE[0],
        height=WINDOW_SIZE[1],
        min_size=MIN_SIZE,
    )
    webview.start()


if __name__ == '__main__':
    main()
