# -*- coding: utf-8 -*-
"""四则运算题目生成器。

生成流程（体现「逆波兰表达式 + 调度场算法」两个底层算法）：

    随机表达式树
        │  to_infix()
        ▼
    中缀表达式字符串   （如 "3 + (4 - 1) × 2"）
        │  tokenize() → shunting_yard()
        ▼
    逆波兰表达式 RPN    （后缀序列）
        │  eval_rpn()
        ▼
    结果 + 约束校验

调度场算法（Shunting-yard）负责「中缀 → 逆波兰」的转换；
eval_rpn 用栈对逆波兰表达式求值，并在求值过程中校验约束。
"""

import random
import re

OPERATORS = ['+', '-', '×', '÷']

# 运算符优先级：乘除高于加减
PRECEDENCE = {'+': 1, '-': 1, '×': 2, '÷': 2}

# 叶子（数字）视为最高优先级
_LEAF_PREC = 3

_TOKEN_RE = re.compile(r'\d+|[+\-×÷()]')


def _node_prec(node):
    """节点优先级：内部节点取运算符优先级，叶子取最高。"""
    return PRECEDENCE[node[0]] if isinstance(node, tuple) else _LEAF_PREC


def build_tree(num_operands, ops, lo, hi):
    """随机生成含 num_operands 个数字的表达式树。

    叶子为 int；内部节点为 (运算符, 左子树, 右子树)。
    返回 (node, value)，value 为该子树的计算结果，供上层「除法整除」判断使用。
    """
    if num_operands <= 1:
        v = random.randint(lo, hi)
        return v, v

    left_n = random.randint(1, num_operands - 1)
    right_n = num_operands - left_n
    op = random.choice(ops)

    left, lv = build_tree(left_n, ops, lo, hi)
    right, rv = build_tree(right_n, ops, lo, hi)

    if op == '÷':
        # 局部重试：保证被除数能被除数整除（除数非零），降低整题被拒概率
        for _ in range(100):
            if rv != 0 and lv % rv == 0:
                break
            if rv == 0:
                right, rv = build_tree(right_n, ops, lo, hi)
            else:
                left, lv = build_tree(left_n, ops, lo, hi)

    if op == '+':
        v = lv + rv
    elif op == '-':
        v = lv - rv
    elif op == '×':
        v = lv * rv
    else:  # '÷'
        v = lv // rv if rv != 0 else lv
    return (op, left, right), v


def to_infix(node):
    """把表达式树转成带「必要括号」的中缀字符串。"""
    if not isinstance(node, tuple):
        return str(node)

    op, left, right = node
    lp, rp = _node_prec(left), _node_prec(right)
    prec = PRECEDENCE[op]

    l = to_infix(left)
    r = to_infix(right)

    # 左子节点：只有优先级更低时才加括号（同级左结合无需括号）
    if lp < prec:
        l = f'({l})'
    # 右子节点：优先级更低，或同级但运算符为 - / ÷（左结合下顺序会变）时加括号
    if rp < prec or (rp == prec and op in ('-', '÷')):
        r = f'({r})'

    return f'{l} {op} {r}'


def tokenize(infix):
    """中缀字符串 → token 列表（数字为 int，运算符/括号为 str）。"""
    return [int(t) if t.isdigit() else t for t in _TOKEN_RE.findall(infix)]


def shunting_yard(tokens):
    """调度场算法：中缀 tokens → 逆波兰(RPN) tokens。

    所有运算符均为左结合，因此出栈条件简化为：栈顶优先级 >= 当前优先级。
    """
    output, stack = [], []
    for tok in tokens:
        if isinstance(tok, int):
            output.append(tok)
        elif tok == '(':
            stack.append(tok)
        elif tok == ')':
            while stack[-1] != '(':
                output.append(stack.pop())
            stack.pop()  # 弹出 '('
        else:  # 运算符
            while stack and stack[-1] != '(' and PRECEDENCE[stack[-1]] >= PRECEDENCE[tok]:
                output.append(stack.pop())
            stack.append(tok)
    while stack:
        output.append(stack.pop())
    return output


def eval_rpn(rpn, require_nonneg=True):
    """栈式求值逆波兰表达式。

    返回 (结果, 是否满足约束)。
    约束：除法必须整除且除数非零；require_nonneg 为 True 时中间结果与最终结果均非负。
    """
    stack = []
    for tok in rpn:
        if isinstance(tok, int):
            stack.append(tok)
            continue

        b = stack.pop()
        a = stack.pop()
        if tok == '+':
            v = a + b
        elif tok == '-':
            v = a - b
        elif tok == '×':
            v = a * b
        else:  # '÷'，要求整除且除数非零
            if b == 0 or a % b != 0:
                return None, False
            v = a // b

        if require_nonneg and v < 0:
            return None, False
        stack.append(v)
    return stack[0], True


def generate_problem(num_operands, ops, lo, hi, require_nonneg=True, max_attempts=5000):
    """生成一道满足约束的题目。

    返回 (中缀字符串, 答案)；若在尝试次数内无法满足约束则返回 (None, None)。
    """
    for _ in range(max_attempts):
        tree, _ = build_tree(num_operands, ops, lo, hi)
        infix = to_infix(tree)
        rpn = shunting_yard(tokenize(infix))
        value, ok = eval_rpn(rpn, require_nonneg)
        if ok:
            return infix, value
    return None, None


def generate_problems(n, num_operands, ops, lo, hi, require_nonneg=True):
    """生成 n 道题。返回 [(中缀字符串, 答案), ...]，失败项为 (None, None)。"""
    return [generate_problem(num_operands, ops, lo, hi, require_nonneg) for _ in range(n)]


def _eval_infix_for_test(infix):
    """用 Python eval 交叉验证答案（仅测试用，运算符已映射）。"""
    return eval(infix.replace('×', '*').replace('÷', '//'))


if __name__ == '__main__':
    # 自检：交叉验证答案、验证 shunting-yard 与直接后序遍历一致、验证约束成立
    configs = [
        (2, ['+', '-', '×', '÷'], 1, 20),
        (3, ['+', '-', '×', '÷'], 1, 20),
        (4, ['+', '-', '×', '÷'], 1, 20),
        (3, ['+', '-'], 1, 100),
        (3, ['×', '÷'], 1, 12),
    ]
    total = 0
    for num_operands, ops, lo, hi in configs:
        for require_nonneg in (True, False):
            for _ in range(300):
                infix, ans = generate_problem(num_operands, ops, lo, hi, require_nonneg)
                if infix is None:
                    print('FAIL 生成失败:', num_operands, ops, lo, hi, require_nonneg)
                    continue
                ref = _eval_infix_for_test(infix)
                if ref != ans:
                    print('MISMATCH:', infix, '算法=', ans, 'eval=', ref)
                rpn = shunting_yard(tokenize(infix))
                v, ok = eval_rpn(rpn, require_nonneg)
                assert v == ans and ok, (infix, v, ans)
                if require_nonneg:
                    assert ans >= 0, infix
                total += 1
    print(f'自检通过：{total} 道题，答案与 shunting-yard/RPN 求值全部一致')
