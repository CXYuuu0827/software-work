const $ = (sel) => document.querySelector(sel);

let problems = [];

const answerModeOn = () => $('#answerMode').checked;

function readInt(id, name) {
  const raw = document.getElementById(id).value.trim();
  if (!/^-?\d+$/.test(raw)) throw `${name} 必须是整数`;
  return parseInt(raw, 10);
}

function selectedOps() {
  return [...document.querySelectorAll('.ops input:checked')].map((cb) => cb.value);
}

function setStatus(msg, isError = false) {
  const el = $('#status');
  el.textContent = msg;
  el.className = 'status' + (isError ? ' error' : '');
}

function showAnswerActive() {
  return !answerModeOn() && $('#showAnswer').checked;
}

function updateControls() {
  const am = answerModeOn();
  $('#showAnswer').disabled = am;
  $('#btnGrade').hidden = !am;
}

function render() {
  const am = answerModeOn();
  const show = showAnswerActive();
  const box = $('#problems');
  box.innerHTML = '';

  problems.forEach((p, i) => {
    const [infix, ans] = p;
    const div = document.createElement('div');
    div.className = 'problem';

    const idx = document.createElement('span');
    idx.className = 'idx';
    idx.textContent = `${i + 1}.`;

    const expr = document.createElement('span');
    expr.className = 'expr';
    expr.textContent = infix === null ? '（生成失败，请放宽约束）' : `${infix} = `;

    div.append(idx, expr);

    if (infix === null) {
      box.appendChild(div);
      return;
    }

    if (am) {
      const input = document.createElement('input');
      input.className = 'ans-input';
      input.type = 'text';
      input.inputMode = 'numeric';
      input.placeholder = '输入答案';
      div.appendChild(input);
    } else {
      const ansSpan = document.createElement('span');
      ansSpan.className = 'ans';
      ansSpan.textContent = show ? String(ans) : '______';
      div.appendChild(ansSpan);
    }

    box.appendChild(div);
  });

  $('#empty').style.display = problems.length ? 'none' : '';
  $('#countInfo').textContent = problems.length ? `共 ${problems.length} 题` : '';
  $('#score').hidden = true;
  $('#score').textContent = '';
}

async function generate() {
  let lo, hi, numOperands, n;
  try {
    lo = readInt('lo', '最小值');
    hi = readInt('hi', '最大值');
    numOperands = readInt('operands', '运算数个数');
    n = readInt('count', '题目数量');
  } catch (e) {
    return setStatus(e, true);
  }

  if (lo < 1 || hi < lo) return setStatus('数字范围不合法（需 1 ≤ 最小值 ≤ 最大值）', true);
  if (numOperands < 2 || numOperands > 5) return setStatus('运算数个数需在 2 ~ 5 之间', true);
  if (n < 1 || n > 200) return setStatus('题目数量需在 1 ~ 200 之间', true);

  const ops = selectedOps();
  if (ops.length === 0) return setStatus('请至少选择一种运算符', true);

  setStatus('正在生成…');
  problems = await window.pywebview.api.generate(n, numOperands, ops, lo, hi, $('#nonneg').checked);
  render();

  const failed = problems.filter((p) => p[0] === null).length;
  setStatus(failed ? `已生成 ${problems.length} 道题（${failed} 道失败，请放宽约束）` : `已生成 ${problems.length} 道题`);
}

function grade() {
  if (!problems.length) return setStatus('请先生成题目', true);

  const rows = document.querySelectorAll('.problem');
  let correct = 0;
  let total = 0;

  rows.forEach((row, i) => {
    const [infix, ans] = problems[i];
    if (infix === null) return;

    total++;
    const input = row.querySelector('.ans-input');
    const ok = input && /^-?\d+$/.test(input.value.trim()) && parseInt(input.value.trim(), 10) === ans;

    if (input) input.disabled = true;

    const mark = document.createElement('span');
    mark.className = 'ans ' + (ok ? 'correct' : 'wrong');
    mark.textContent = ok ? `✓ ${ans}` : `✗ 正确答案：${ans}`;
    row.appendChild(mark);

    if (ok) correct++;
  });

  if (total === 0) return setStatus('没有可批改的题目（题目均生成失败）', true);

  const score = Math.round((correct * 100) / total);
  const scoreEl = $('#score');
  scoreEl.hidden = false;
  scoreEl.textContent = `得分：${score} 分（${correct}/${total}）`;
  scoreEl.className = 'score ' + (score >= 60 ? 'pass' : 'fail');

  setStatus(`批改完成：答对 ${correct} / ${total} 题`);
}

async function exportText() {
  if (!problems.length) return setStatus('请先生成题目', true);

  const show = showAnswerActive();
  const lines = problems.map((p, i) => {
    const [infix, ans] = p;
    const body = infix === null ? '（生成失败）' : `${infix} = ${show ? ans : '______'}`;
    return `${i + 1}. ${body}`;
  });

  const res = await window.pywebview.api.export(lines.join('\n'));
  if (res.cancelled) return;
  setStatus(res.ok ? `已保存到：${res.path}` : '保存失败', !res.ok);
}

$('#btnGenerate').addEventListener('click', generate);
$('#btnGrade').addEventListener('click', grade);
$('#btnExport').addEventListener('click', exportText);
$('#showAnswer').addEventListener('change', () => { if (!answerModeOn()) render(); });
$('#answerMode').addEventListener('change', () => { updateControls(); render(); });

updateControls();
